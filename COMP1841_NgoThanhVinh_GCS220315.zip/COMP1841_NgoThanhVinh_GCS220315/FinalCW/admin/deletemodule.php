<?php

include '../includes/DatabaseConnection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Câu lệnh SQL để xóa một bản ghi khỏi bảng 'module' dựa trên ID
        $sql = 'DELETE FROM module WHERE id = :id';
        
        
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':id', $_POST['id'], PDO::PARAM_INT);
        $stmt->execute();

        
        header('Location:modules.php');
        exit; 
    } catch (PDOException $e) {
        echo 'Database error: ' . $e->getMessage();
    }
}
?>
