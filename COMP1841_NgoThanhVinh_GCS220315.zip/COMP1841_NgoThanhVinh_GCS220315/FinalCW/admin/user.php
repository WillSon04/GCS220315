<?php
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';


$users = allUsers($pdo); // Lấy tất cả người dùng
$title = 'Manage Users';  // Đặt tiêu đề trang
ob_start();  // Bắt đầu bộ đệm đầu ra
?>

<h1>Manage Users</h1>

<a href="../admin/adduser.php" class="button">Add User</a>


<table>
    <tr>
       
        <th>ID</th>
        <th>Username</th>
        <th>Email</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($users as $user): ?>
    <tr>
        <!-- Hiển thị thông tin người dùng -->
        <td><?= htmlspecialchars($user['id'], ENT_QUOTES, 'UTF-8') ?></td>
        <td><?= htmlspecialchars($user['name'], ENT_QUOTES, 'UTF-8') ?></td>
        <td><?= htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8') ?></td>
        <td>
           
            <a href="../admin/edituser.php?id=<?= $user['id'] ?>">Edit</a>
            <!-- Form để xóa người dùng -->
            <form action="../admin/deleteuser.php" method="post" style="display:inline;">
                <input type="hidden" name="id" value="<?= $user['id'] ?>">
                <input type="submit" value="Delete">
            </form>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

<?php
// Kết thúc bộ đệm đầu ra và lưu vào biến $output
$output = ob_get_clean();

include '../template/admin_layout.html.php';
?>
