<?php
include '../includes/DatabaseConnection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Câu lệnh SQL để xóa một bản ghi khỏi bảng 'user' dựa trên ID
        $sql = 'DELETE FROM user WHERE id = :id';
    
        $stmt = $pdo->prepare($sql);
        
        // Gắn giá trị ID từ dữ liệu gửi lên (POST) vào tham số :id trong câu SQL
        $stmt->bindValue(':id', $_POST['id'], PDO::PARAM_INT);
        $stmt->execute();

        header('Location:../admin/user.php');
        exit; 
    } catch (PDOException $e) {
        echo 'Database error: ' . $e->getMessage();
    }
}
?>
