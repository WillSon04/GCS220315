<?php
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';


$modules = allModules($pdo); // Lấy danh sách tất cả modules
$title = 'Manage Modules';
ob_start();
?>

<h1>Manage Modules</h1>
<a href="../admin/addmodule.php" class="button">Add Module</a>

<table>
    <tr>
        <!-- Đầu bảng: ID, Module -->
        <th>ID</th>
        <th>Module Name</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($modules as $module): ?>
    <tr>
        <!-- Hiển thị ID của module -->
        <td><?= htmlspecialchars($module['id'], ENT_QUOTES, 'UTF-8') ?></td>
        <!-- Hiển thị tên module -->
        <td><?= htmlspecialchars($module['ModuleName'], ENT_QUOTES, 'UTF-8') ?></td>
        <td>
            <!-- Liên kết đến trang chỉnh sửa module -->
            <a href="../admin/editmodule.php?id=<?= $module['id'] ?>">Edit</a>
            <!-- Form xóa module, yêu cầu người dùng gửi ID module -->
            <form action="../admin/deletemodule.php" method="post" style="display:inline;">
                <!-- Ẩn ID module trong form khi gửi -->
                <input type="hidden" name="id" value="<?= $module['id'] ?>">
                <!-- Nút để gửi form và xóa module -->
                <input type="submit" value="Delete">
            </form>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

<?php
// Lấy dữ liệu HTML đã được xử lý và lưu vào biến $output
$output = ob_get_clean();
include '../template/admin_layout.html.php';
?>

