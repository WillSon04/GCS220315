<?php
// Kết nối đến cơ sở dữ liệu
include '../includes/DatabaseConnection.php';

// Kiểm tra xem form được submit chua
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Kiểm tra nếu các trường 'name' và 'email' không rỗng
        if (!empty($_POST['name']) && !empty($_POST['email'])) {
            // Lấy dữ liệu từ form và xóa khoảng trắng thừa
            $name = trim($_POST['name']);
            $email = trim($_POST['email']);

            // Chuẩn bị câu lệnh SQL để chèn dữ liệu vào bảng 'user'
            $sql = 'INSERT INTO user (name, email) VALUES (:name, :email)';
            $stmt = $pdo->prepare($sql); // Chuẩn bị truy vấn
            $stmt->bindValue(':name', $name); // Gắn giá trị của tên
            $stmt->bindValue(':email', $email); // Gắn giá trị của email
            $stmt->execute(); // Thực thi truy vấn

            // Chuyển hướng về trang danh sách người dùng sau khi thêm thành công
            header('Location:../admin/user.php');
            exit; 
        } else {
            
            $error = "Please fill in all fields.";
        }
    } catch (PDOException $e) {
        
        $error = 'Database error: ' . $e->getMessage();
    }
}

$title = 'Add User';
// Bắt đầu bộ nhớ đệm để tạo nội dung HTML
ob_start();
?>


<h1>Add User</h1>
<!-- Hiển thị lỗi nếu có -->
<?php if (isset($error)): ?>
<p style="color: red;"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
<?php endif; ?>

<!-- Form thêm người dùng -->
<form action="../admin/adduser.php" method="post">
    <label for="name">Username:</label>
    <input type="text" name="name" id="name" required><br><br>
    <label for="email">Email:</label>
    <input type="email" name="email" id="email" required><br><br>
    <button type="submit">Add User</button>
</form>

<?php
// Lấy nội dung HTML đã tạo từ bộ nhớ đệm
$output = ob_get_clean();

include '../template/admin_layout.html.php';
?>
