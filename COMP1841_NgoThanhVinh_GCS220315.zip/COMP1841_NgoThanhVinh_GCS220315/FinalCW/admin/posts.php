<?php
require "login/Check.php";
try{
    include '../includes/DatabaseConnection.php';
    include '../includes/DatabaseFunctions.php';

    //$sql = 'SELECT joke.id, joketext,`name`,email,categoryName FROM joke
    //INNER JOIN author ON authorid = author.id
    //INNER JOIN category ON categoryid = category.id';
    $posts = allPosts($pdo);
    $title = 'post list';
    $totalPosts = totalPosts($pdo);

    ob_start();
    include 'posts.html.php';
    $output = ob_get_clean();   
}catch(PDOException $e) {
    $title = 'An error has occured';
    $output = 'Database error:' . $e->getMessage();
}
include '../template/admin_layout.html.php';