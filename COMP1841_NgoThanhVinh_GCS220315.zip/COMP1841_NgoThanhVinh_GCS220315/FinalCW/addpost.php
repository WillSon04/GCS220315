<?php

if(isset($_POST['posttext'])){
    try{
        include 'includes/DatabaseConnection.php';
        include 'includes/DatabaseFunctions.php';
        
        
        insertPost($pdo,$_POST['posttext'],$_POST['users'],$_POST['modules'],$_FILES['fileToUpload']['name']);
        include 'includes/uploadFile.php';
        header('location: posts.php');
    }catch(PDOException $e){
        $title = 'an error has occurred';
        $output = 'Database error:' . $e->getMessage();
    }
}else{
    include 'includes/DatabaseConnection.php';
    include 'includes/DatabaseFunctions.php';
    $title = 'add a new post';
    //$sql_a = 'SELECT * FROM author';
    $users = allUsers($pdo);
    //$sql_c = 'SELECT * FROM category';
    $modules = allModules($pdo);
    ob_start();
    include 'template/addpost.html.php';
    $output = ob_get_clean();
}



// Insert post into database
if (!empty($_POST['posttext'])) {
    
}


include 'template/layout.html.php';
