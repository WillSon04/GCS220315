<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="../posts.css">
        <title><?=$title?></title>
    </head>
    <body>
        <header id="admin">
            <h1>INTERNET POST DATABASE ADMIN AREA<br />
                </h1></header>
        <nav>
            <ul>
             
                <li><a href="posts.php">Post list</a></li>
                <li><a href="addpost.php">Add a new post</a></li>
                <li><a href="user.php">Manage User</a></li>
                <li><a href="modules.php">Manage Module</a></li>
                <li><a href="login/Logout.php">Public site/Logout</a></li>
            </ul>
        </nav>
        <main>
            <?=$output?>
        </main>
        <footer>&copy; IJDB 2023</footer>
    </body>
</html>