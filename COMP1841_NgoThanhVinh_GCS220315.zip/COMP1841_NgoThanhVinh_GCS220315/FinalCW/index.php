<?php

session_start();

// Kiểm tra nếu trạng thái menu đã được lưu trong session
if (isset($_GET['toggle'])) {
    // Lưu trạng thái mở/đóng menu vào session
    $_SESSION['menu_open'] = !isset($_SESSION['menu_open']) || $_SESSION['menu_open'] == false;
}

// Đặt giá trị mặc định nếu chưa có trong session
if (!isset($_SESSION['menu_open'])) {
    $_SESSION['menu_open'] = false;
}

$title = 'Internet posts Database';
ob_start();
include 'template/home.html.php';
$output = ob_get_contents();
include 'template/layout.html.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Menu Toggle</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Hamburger Menu -->
    <div class="menu-container">
        <div class="hamburger-menu">
            <!-- Nhấn vào để thay đổi trạng thái -->
            <a href="?toggle=true">&#9776;</a> 
        </div>

        <div class="menu <?php echo $_SESSION['menu_open'] ? 'show' : ''; ?>" id="menu">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="posts.php">Posts List</a></li>
                <li><a href="addpost.php">About</a></li>
                <li><a href="users.php">User</a></li>
                <li><a href="modules.php">Module</a></li>
                <li><a href="admin/login/login.html">Admin Login</a></li>
            </ul>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>
