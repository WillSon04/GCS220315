<?php 
include 'includes/DatabaseConnection.php';
include 'includes/DatabaseFunctions.php';

try {
    // Xử lý khi dữ liệu được gửi qua POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['postid'], $_POST['posttext'], $_POST['userid'], $_POST['moduleid']) 
            && !empty($_POST['postid']) 
            && !empty($_POST['posttext']) 
            && is_numeric($_POST['postid']) 
            && is_numeric($_POST['userid']) 
            && is_numeric($_POST['moduleid'])) {

            // Lấy dữ liệu từ POST
            $postid = $_POST['postid'];
            $posttext = $_POST['posttext'];
            $userid = $_POST['userid'];
            $moduleid = $_POST['moduleid'];

            // Thực hiện cập nhật
            updatePost($pdo, $postid, $posttext, $userid, $moduleid);

            // Chuyển hướng sau khi cập nhật thành công
            header('Location: posts.php');
            exit;
        } else {
            throw new Exception('Invalid or missing input data.');
        }
    }
    // Xử lý khi dữ liệu được yêu cầu qua GET
    elseif (isset($_GET['id']) && !empty($_GET['id']) && is_numeric($_GET['id'])) {
        // Lấy thông tin bài viết
        $post = getPost($pdo, $_GET['id']);
        if (!$post) {
            throw new Exception('Post not found.');
        }

        // Lấy danh sách người dùng và modules
        $title = 'Edit post';
        $users = allUsers($pdo);
        $modules = allModules($pdo);

        // Tải template
        ob_start();
        include 'template/editpost.html.php';
        $output = ob_get_clean();
    } else {
        throw new Exception('Post ID is missing.');
    }
} catch (PDOException $e) {
    $title = 'An error has occurred';
    $output = 'Error editing post: ' . $e->getMessage();
} catch (Exception $e) {
    $title = 'An error has occurred';
    $output = $e->getMessage();
}

include 'template/layout.html.php';
